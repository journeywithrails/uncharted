-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 21, 2008 at 04:04 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `mbma_sadevelopment`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` varchar(32) NOT NULL,
  `status` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` VALUES(3, 'a6bBbs5OOr3jCXadbiKLMM', 0);
INSERT INTO `admin_users` VALUES(11, 'csUjJC5WSr3j5ZadbiKLMM', 1);
INSERT INTO `admin_users` VALUES(12, 'cJnEQ06mOr3kZOadbiKLMM', 0);
INSERT INTO `admin_users` VALUES(13, 'a8IkKG6m0r3lrkadbiKLMM', 0);
INSERT INTO `admin_users` VALUES(14, 'c4meXc6nar3l_qadbiKLMM', 1);
INSERT INTO `admin_users` VALUES(15, 'aGQCYO6ner3jm_adbiKLMM', 1);
INSERT INTO `admin_users` VALUES(16, 'drpbRQ6qCr3l09adbiKLMM', 1);
INSERT INTO `admin_users` VALUES(17, 'axdG9A6qKr3iwJadbiKLMM', 1);
INSERT INTO `admin_users` VALUES(18, 'aOmqv66qOr3jhMadbiKLMM', 1);
INSERT INTO `admin_users` VALUES(19, 'acw3JY6qSr3kRJadbiKLMM', 1);
INSERT INTO `admin_users` VALUES(20, 'c-GWRk6q0r3jZcadbiKLMM', 1);
INSERT INTO `admin_users` VALUES(21, 'aluJPk6Aer3lB5adbiKLMM', 0);
INSERT INTO `admin_users` VALUES(22, 'bMEACe6AWr3kmXadbiKLMM', 0);

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL auto_increment,
  `article_category_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `article_title` varchar(225) default NULL,
  `article_body` text,
  `article_image` varchar(225) default NULL,
  `featured` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` VALUES(7, 2, 1, 'Ruby on Rails', '			<strong>																		Lorem ipsum</strong> dolor sit amet, consectetuer adipiscing elit. Duis ligula lorem, consequat eget, tristique nec, auctor quis, purus. Vivamus ut sem. Fusce aliquam nunc vitae purus. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis ligula lorem, consequat eget, tristique nec, auctor quis, purus. Vivamus ut sem. Fusce aliquam nunc vitae purus. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis ligula lorem, consequat eget, tristique nec, auctor quis, purus. Vivamus ut sem. Fusce aliquam nunc vitae purus. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis ligula lorem, consequat eget, tristique nec, auctor quis, purus. Vivamus ut sem. Fusce aliquam nunc vitae purus 			 			 			 			 			 			 			', 'lrg_1000_hawaii.jpg', 1, '2008-02-29 03:10:37', '2008-04-08 06:28:51');
INSERT INTO `articles` VALUES(5, 2, 1, 'ipod', '									ipod  			 			 			', 'ipod_75x75.jpg', 1, '2008-02-28 23:07:22', '2008-02-29 03:07:00');
INSERT INTO `articles` VALUES(6, 2, 1, 'VCDs', '<strong>															This is an image of sivaji.</strong> 			 			 			 			 			', 'rajinkanth_75x75.gif', 1, '2008-02-29 02:42:16', '2008-02-29 03:04:14');
INSERT INTO `articles` VALUES(8, 1, 1, 'BOOKS', 'BOOKS&nbsp;&nbsp;  ', 'image0012.jpg', NULL, '2008-04-09 06:41:09', '2008-04-09 06:41:09');

-- --------------------------------------------------------

--
-- Table structure for table `article_categories`
--

CREATE TABLE `article_categories` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(225) default NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `article_categories`
--

INSERT INTO `article_categories` VALUES(1, 'new category', '2008-01-17 03:01:18', '2008-01-17 03:01:18');
INSERT INTO `article_categories` VALUES(2, 'Budget', '2008-02-28 21:23:54', '2008-02-28 21:23:54');
INSERT INTO `article_categories` VALUES(3, 'Books', '2008-02-29 03:07:55', '2008-02-29 03:07:55');
INSERT INTO `article_categories` VALUES(4, 'Computers', '2008-02-29 03:08:56', '2008-02-29 03:08:56');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(225) NOT NULL,
  `image` varchar(225) NOT NULL,
  `sub_image` varchar(225) NOT NULL,
  `created_at` date NOT NULL,
  `edited_at` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` VALUES(1, 'header', 'ban_728x90_DC01-ani.gif', 'ban_120x90_spa01.gif', '2008-04-01', '2008-04-08');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` varchar(32) NOT NULL,
  `event_date` datetime default NULL,
  `event_title` varchar(225) NOT NULL,
  `event_location` varchar(225) default NULL,
  `event_description` text,
  `url` varchar(225) default NULL,
  `suggestion` tinyint(4) default '0',
  `created_at` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` VALUES(32, 'a6bBbs5OOr3jCXadbiKLMM', '2008-05-19 15:57:00', 'nyc bbq', 'nyc', 'Do you have a friend that you think would be a valuable addition to our community? SEASONED ADVENTURER is an invitation-only, private social network, but if you would like to suggest someone to be reviewed for possible membership, please suggest a member. ', 'http://www.seasonedadventurer.com/event/suggest', 1, '2008-05-19 15:58:05');
INSERT INTO `events` VALUES(31, 'cQ-CDgYzer3i8_adbiKLMM', '2009-02-26 22:19:00', 'testing', 'new place', 'craeted for new events', '', 1, '2008-03-31 23:24:00');
INSERT INTO `events` VALUES(30, 'cQ-CDgYzer3i8_adbiKLMM', '2008-04-24 00:00:00', 'new event', 'Bombay', 'about the new event', '', 1, '2008-03-31 22:46:54');
INSERT INTO `events` VALUES(29, 'cQ-CDgYzer3i8_adbiKLMM', '2008-03-31 22:40:00', 'qq', 'qq', 'qq', 'qq', 1, '2008-03-31 22:41:17');
INSERT INTO `events` VALUES(27, 'a6bBbs5OOr3jCXadbiKLMM', '2008-02-20 00:00:00', 'test', 'test', 'test', NULL, 1, '2008-02-29 06:13:17');
INSERT INTO `events` VALUES(28, 'cQ-CDgYzer3i8_adbiKLMM', '2008-03-31 22:20:00', 'nbmnm', 'bnmbn', 'good', 'mbnmbnm', 0, '2008-03-31 22:40:22');
INSERT INTO `events` VALUES(25, 'a6bBbs5OOr3jCXadbiKLMM', '2008-02-19 00:00:00', 'test', 'test', 'test', NULL, 1, '2008-02-29 01:13:38');
INSERT INTO `events` VALUES(26, 'a6bBbs5OOr3jCXadbiKLMM', '2008-02-28 00:00:00', 'fgdfg', 'fgdg565656', 'fgjkjklj', NULL, 0, '2008-02-29 05:54:23');
INSERT INTO `events` VALUES(21, 'b1sClA5pKr3lbMadbiKLMM', '2008-02-29 00:00:00', 'chaitu', 'india', 'chaitu', '', 0, '2008-02-27 03:01:46');
INSERT INTO `events` VALUES(20, 'b1sClA5pKr3lbMadbiKLMM', '2008-02-27 02:56:00', 'Test Event', 'Test Event', 'Test Event', 'Test Event', 0, '2008-02-27 02:57:11');
INSERT INTO `events` VALUES(33, 'a6bBbs5OOr3jCXadbiKLMM', '2008-05-20 23:32:00', 'new event in india', 'india', 'new event is going to be held in india, so please visit it', '', 0, '2008-05-20 23:33:32');

-- --------------------------------------------------------

--
-- Table structure for table `feed_backs`
--

CREATE TABLE `feed_backs` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` varchar(150) NOT NULL default '0',
  `Subject` varchar(255) NOT NULL default '',
  `Description` text NOT NULL,
  `file` varchar(255) default NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` int(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `feed_backs`
--

INSERT INTO `feed_backs` VALUES(12, 'b1sClA5pKr3lbMadbiKLMM', 'test', 'test', NULL, '2008-02-27 03:03:02', 0);
INSERT INTO `feed_backs` VALUES(13, 'b6ZlCa5pWr3lj_adbiKLMM', 'testing contact details', 'check out', 'rails.png', '2008-02-27 05:54:07', 0);
INSERT INTO `feed_backs` VALUES(14, 'cQ-CDgYzer3i8_adbiKLMM', 'testing', 'created for testing by testuser', NULL, '2008-03-03 05:24:34', 0);
INSERT INTO `feed_backs` VALUES(15, 'cQ-CDgYzer3i8_adbiKLMM', 'inquiry', 'inquiry', NULL, '2008-03-31 04:04:30', 0);
INSERT INTO `feed_backs` VALUES(16, 'a6bBbs5OOr3jCXadbiKLMM', 'good wesite', 'its an good website', NULL, '2008-04-01 05:31:58', 0);

-- --------------------------------------------------------

--
-- Table structure for table `forum_categories`
--

CREATE TABLE `forum_categories` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(150) NOT NULL default '',
  `description` varchar(255) default NULL,
  `active` int(11) default '1',
  `created_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `forum_categories`
--

INSERT INTO `forum_categories` VALUES(7, 'Business forum', 'This category mainly belongs to Business ', 1, '2008-01-22 00:02:24');
INSERT INTO `forum_categories` VALUES(8, 'Travel forum', 'This forum is created for posting all the travel related stuff and their functionality', 1, '2008-01-22 00:34:08');
INSERT INTO `forum_categories` VALUES(9, 'home exchange', 'this forum is created for posting forum topics on rental....', 1, '2008-01-24 05:52:49');

-- --------------------------------------------------------

--
-- Table structure for table `forum_posts`
--

CREATE TABLE `forum_posts` (
  `id` int(11) NOT NULL auto_increment,
  `forum_category_id` int(11) NOT NULL default '0',
  `forum_thread_id` int(11) NOT NULL default '0',
  `user_id` varchar(32) NOT NULL default '0',
  `subject` varchar(150) NOT NULL default '',
  `content` text NOT NULL,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `forum_posts`
--

INSERT INTO `forum_posts` VALUES(26, 7, 13, 'b1sClA5pKr3lbMadbiKLMM', 'Business', 'Business category', '2008-02-27 02:54:44');
INSERT INTO `forum_posts` VALUES(29, 9, 14, 'd25r565pKr3kSqadbiKLMM', 'testing', 'testing2', '2008-02-27 05:01:43');
INSERT INTO `forum_posts` VALUES(31, 9, 14, 'a6bBbs5OOr3jCXadbiKLMM', 'testing', 'hai testing', '2008-02-29 01:29:05');
INSERT INTO `forum_posts` VALUES(32, 9, 16, 'a6bBbs5OOr3jCXadbiKLMM', 'hello', 'this is for test.', '2008-02-29 03:16:06');
INSERT INTO `forum_posts` VALUES(34, 9, 17, 'a6bBbs5OOr3jCXadbiKLMM', 'test', 'this is for test.', '2008-02-29 03:44:02');
INSERT INTO `forum_posts` VALUES(36, 9, 18, 'a6bBbs5OOr3jCXadbiKLMM', 'gopi', 'gopi', '2008-02-29 03:49:56');
INSERT INTO `forum_posts` VALUES(37, 9, 18, 'a6bBbs5OOr3jCXadbiKLMM', 'gopi', 'gopi', '2008-02-29 03:50:24');
INSERT INTO `forum_posts` VALUES(39, 9, 19, 'a6bBbs5OOr3jCXadbiKLMM', 'gopi', 'gopi1', '2008-02-29 04:01:20');
INSERT INTO `forum_posts` VALUES(40, 9, 19, 'a6bBbs5OOr3jCXadbiKLMM', 'gopi', 'g1', '2008-02-29 04:02:13');
INSERT INTO `forum_posts` VALUES(41, 8, 12, 'a6bBbs5OOr3jCXadbiKLMM', 'For Travlleling', 'test reply', '2008-02-29 04:07:43');
INSERT INTO `forum_posts` VALUES(42, 7, 13, 'a6bBbs5OOr3jCXadbiKLMM', 'Business', 'new business', '2008-02-29 04:16:11');
INSERT INTO `forum_posts` VALUES(43, 7, 13, 'a6bBbs5OOr3jCXadbiKLMM', 'Business', 'hai', '2008-02-29 05:25:25');
INSERT INTO `forum_posts` VALUES(44, 8, 12, 'a6bBbs5OOr3jCXadbiKLMM', 'For Travlleling', 'hai', '2008-02-29 05:26:53');
INSERT INTO `forum_posts` VALUES(45, 7, 20, 'a6bBbs5OOr3jCXadbiKLMM', 'fdghtr', 'ghjhg', '2008-02-29 06:29:46');
INSERT INTO `forum_posts` VALUES(46, 0, 20, 'a6bBbs5OOr3jCXadbiKLMM', 'RE', 'testing ', '2008-02-29 14:28:56');
INSERT INTO `forum_posts` VALUES(47, 0, 13, 'dsGgZ85iOr3lZpadbiKLMM', 'RE', 'test by Dennis', '2008-03-02 20:43:55');
INSERT INTO `forum_posts` VALUES(48, 8, 21, 'a6bBbs5OOr3jCXadbiKLMM', 'for traveling', 'traveling forum content', '2008-03-02 22:49:16');
INSERT INTO `forum_posts` VALUES(49, 8, 21, 'a6bBbs5OOr3jCXadbiKLMM', 'for traveling', 'hello', '2008-03-02 22:50:24');
INSERT INTO `forum_posts` VALUES(50, 7, 22, 'bMEACe6AWr3kmXadbiKLMM', 'My Test', 'Just for test post', '2008-03-05 00:56:26');
INSERT INTO `forum_posts` VALUES(51, 0, 22, 'cQ-CDgYzer3i8_adbiKLMM', 'RE', 'hai martha how r u', '2008-03-31 03:55:43');
INSERT INTO `forum_posts` VALUES(52, 7, 23, 'cQ-CDgYzer3i8_adbiKLMM', 'new post', 'message craeted for testing', '2008-03-31 03:56:45');
INSERT INTO `forum_posts` VALUES(53, 9, 24, 'cQ-CDgYzer3i8_adbiKLMM', 'House in the Hamptons', 'I have a house in the Hamptons, looking to trade for one in Rome.', '2008-04-19 03:56:49');
INSERT INTO `forum_posts` VALUES(54, 0, 24, 'a6bBbs5OOr3jCXadbiKLMM', 'RE', 'Okay, I have one in Rome.  Call me: 5500443322', '2008-05-19 15:53:02');

-- --------------------------------------------------------

--
-- Table structure for table `forum_threads`
--

CREATE TABLE `forum_threads` (
  `id` int(11) NOT NULL auto_increment,
  `forum_category_id` int(11) NOT NULL default '0',
  `forum_post_id` int(11) NOT NULL default '0',
  `user_id` varchar(32) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `forum_threads`
--

INSERT INTO `forum_threads` VALUES(13, 7, 26, 'b1sClA5pKr3lbMadbiKLMM');
INSERT INTO `forum_threads` VALUES(14, 9, 29, 'd25r565pKr3kSqadbiKLMM');
INSERT INTO `forum_threads` VALUES(19, 9, 39, 'a6bBbs5OOr3jCXadbiKLMM');
INSERT INTO `forum_threads` VALUES(20, 7, 45, 'a6bBbs5OOr3jCXadbiKLMM');
INSERT INTO `forum_threads` VALUES(21, 8, 48, 'a6bBbs5OOr3jCXadbiKLMM');
INSERT INTO `forum_threads` VALUES(22, 7, 50, 'bMEACe6AWr3kmXadbiKLMM');
INSERT INTO `forum_threads` VALUES(23, 7, 52, 'cQ-CDgYzer3i8_adbiKLMM');
INSERT INTO `forum_threads` VALUES(24, 9, 53, 'cQ-CDgYzer3i8_adbiKLMM');

-- --------------------------------------------------------

--
-- Table structure for table `invitations`
--

CREATE TABLE `invitations` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` varchar(15) NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `name` varchar(225) default NULL,
  `email` varchar(150) NOT NULL default '',
  `reason` varchar(255) NOT NULL default '',
  `comment` varchar(255) NOT NULL default '',
  `status` int(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `invitations`
--

INSERT INTO `invitations` VALUES(10, 'cQ-CDgYzer3i8_a', '2008-02-26', 'chaitu', 'chaitanyab_nyros@yahoo.com', 'He increases the network..', 'Good person', 0);
INSERT INTO `invitations` VALUES(11, 'cQ-CDgYzer3i8_a', '2008-02-26', 'siva krishna', 'sivakrishna_nyros@yahoo.com', 'Because of , he is very nice person and also he have more talking skills', 'nice to work with him', 0);
INSERT INTO `invitations` VALUES(12, 'aNL1N-5pGr3kzTa', '2008-02-26', 'srikanth', 'chaitanyab_nyros@yahoo.com', 'To help SEASONED ADVENTURER community to grow further', 'Good', 0);
INSERT INTO `invitations` VALUES(13, 'd25r565pKr3kSqa', '2008-02-27', 'krishna', 'sivakrishna.motamarri@gmail.com', 'This person is work minded', 'nice to work with him', 0);
INSERT INTO `invitations` VALUES(14, 'd25r565pKr3kSqa', '2008-02-27', 'raja', 'sivakrishna_nyros@yahoo.com', 'asdsad', 'asdasd', 0);
INSERT INTO `invitations` VALUES(15, 'd25r565pKr3kSqa', '2008-02-27', 'Rani', 'ranilaxmi29@yahoo.com', 'To increase the network', 'nice to work', 0);
INSERT INTO `invitations` VALUES(16, 'cJnEQ06mOr3kZOa', '2008-03-02', 'Dennis3', 'dennis711@earthlink.net', 'Good guy', 'Even better guy', 0);
INSERT INTO `invitations` VALUES(17, 'cQ-CDgYzer3i8_a', '2008-03-03', 'mahesh', 'umamahesh_nyros@yahoo.com', 'hai', 'hai', 0);
INSERT INTO `invitations` VALUES(18, 'cQ-CDgYzer3i8_a', '2008-03-03', 'mahesh', 'umamahesh_nyros@yahoo.com', 'hai', 'hai', 0);
INSERT INTO `invitations` VALUES(19, 'cQ-CDgYzer3i8_a', '2008-03-19', 'Ikin', 'ikinwirawan@gmail.com', 'adadf', 'adfasdf', 0);
INSERT INTO `invitations` VALUES(20, 'cQ-CDgYzer3i8_a', '2008-03-31', 'ruby', 'dgd@ssfs.nm', 'ruby on rails', 'ruby on rails', 0);
INSERT INTO `invitations` VALUES(21, 'cQ-CDgYzer3i8_a', '2008-03-31', 'murali', 'murali_nyros@yahoo.com', 'good at .net', 'good working skills', 0);
INSERT INTO `invitations` VALUES(22, 'cQ-CDgYzer3i8_a', '2008-04-01', 'mahesh', 'umamahesh_nyros@yahoo.com', 'hai mahesh', 'hai', 0);
INSERT INTO `invitations` VALUES(23, 'cQ-CDgYzer3i8_a', '2008-04-01', 'mahesh', 'umamahesh_nyros@yahoo.com', 'dfgdfg', '', 0);
INSERT INTO `invitations` VALUES(24, 'dsGgZ85iOr3lZpa', '2008-04-03', 'dennis Payne', 'dennis711@earthlink.net', 'Because', 'Because paragraph 2', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` varchar(32) NOT NULL,
  `name` varchar(225) default NULL,
  `title` varchar(225) default NULL,
  `description` text,
  `price` float default NULL,
  `image` varchar(225) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` VALUES(5, 'dhQnF2Yzer3kYDadbiKLMM', 'silver', 'silver article', 'created for testing the silver article for getting price', 4567, '--3.jpg', '2008-01-29 23:06:46', '2008-02-28 22:53:35');
INSERT INTO `products` VALUES(4, 'dhQnF2Yzer3kYDadbiKLMM', 'Gold', 'gold item', 'new product created for testing in the products item', 1234.56, '--10.jpg', '2008-01-29 23:06:02', '2008-01-29 23:06:02');
INSERT INTO `products` VALUES(6, 'dhQnF2Yzer3kYDadbiKLMM', 'Diamond', 'Diamonds Articles', 'created for testing the products article', 45679, 'd-1.jpg', '2008-01-29 23:07:43', '2008-01-29 23:07:43');
INSERT INTO `products` VALUES(7, 'dhQnF2Yzer3kYDadbiKLMM', 'Gold', 'gold article', 'testing', 34556, '--7.jpg', '2008-01-29 23:08:48', '2008-01-29 23:08:48');
INSERT INTO `products` VALUES(8, 'dhQnF2Yzer3kYDadbiKLMM', 'silver', 'silver', 'testing', 4.35635e+06, 'd---6.jpg', '2008-01-29 23:09:25', '2008-01-29 23:09:25');
INSERT INTO `products` VALUES(9, 'dhQnF2Yzer3kYDadbiKLMM', 'diamond', 'diamond', 'testing for diamond', 45646, 'gld6.jpg', '2008-01-29 23:10:11', '2008-02-12 21:28:10');
INSERT INTO `products` VALUES(12, '3', 'vinayaka', 'vinayaka', 'god books', 345, 'vinayak.bmp', '2008-02-22 05:54:37', '2008-02-22 06:07:54');

-- --------------------------------------------------------

--
-- Table structure for table `schema_info`
--

CREATE TABLE `schema_info` (
  `version` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schema_info`
--


-- --------------------------------------------------------

--
-- Table structure for table `sitealizer`
--

CREATE TABLE `sitealizer` (
  `id` int(11) NOT NULL auto_increment,
  `path` varchar(255) default NULL,
  `ip` varchar(255) default NULL,
  `referer` varchar(255) default NULL,
  `language` varchar(255) default NULL,
  `user_agent` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `created_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sitealizer`
--


-- --------------------------------------------------------

--
-- Table structure for table `site_news`
--

CREATE TABLE `site_news` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) default NULL,
  `title` varchar(150) default NULL,
  `image` varchar(500) default NULL,
  `status` tinyint(4) default NULL,
  `description` text,
  `created_at` datetime NOT NULL default '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `site_news`
--

INSERT INTO `site_news` VALUES(5, '', '', 'image001a.jpg', NULL, '', '2008-03-03 06:07:59', '2008-03-03 06:07:59');
INSERT INTO `site_news` VALUES(6, '', '', NULL, NULL, '', '2008-03-03 21:07:18', '2008-03-03 21:07:18');

-- --------------------------------------------------------

--
-- Table structure for table `testusers`
--

CREATE TABLE `testusers` (
  `id` varchar(32) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testusers`
--

INSERT INTO `testusers` VALUES('aQwp9uYzar3l2RadbiKLMM', 'mahesh');
INSERT INTO `testusers` VALUES('bAOwNAYzar3lKnadbiKLMM', 'dsgsdg');
INSERT INTO `testusers` VALUES('bTt-IUYzar3ieqadbiKLMM', 'sdgdsg');
INSERT INTO `testusers` VALUES('bYLiZYYzar3iNvadbiKLMM', 'sdgdsg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(32) NOT NULL,
  `email` varchar(225) default NULL,
  `First_Name` varchar(225) default NULL,
  `Last_Name` varchar(225) default NULL,
  `Gender` varchar(15) default NULL,
  `primary_residence` text,
  `City` varchar(225) default NULL,
  `State` varchar(225) default NULL,
  `Country` varchar(225) default NULL,
  `birthday` date default NULL,
  `places_lived` text,
  `places_traveled` text,
  `personal_interests` text,
  `work_life` text,
  `future_plans` text,
  `reference` text,
  `value_life` text,
  `profile_image` varchar(225) default NULL,
  `industry` varchar(225) default NULL,
  `crypted_password` varchar(40) default NULL,
  `salt` varchar(40) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `logged_in` tinyint(4) default '0',
  `last_login` datetime default NULL,
  `remember_token` varchar(225) default NULL,
  `remember_token_expires_at` datetime default NULL,
  `status` int(11) default '0',
  `network` int(15) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES('c-GWRk6q0r3jZcadbiKLMM', 'dsf@dsad.co', 'rakesh', 'gruda', 'female', 'fdgfdg', 'sdfsd', 'fdsf', 'United States', '2008-03-12', 'all', 'all', 'all', 'al', 'all', NULL, 'all', '133385360_4ee2c94b00_m.jpg', NULL, '7e1610e412f40827069cb9626ab42b3f02c67fd6', '93062c5d565352065707e9b2b36e0b99d6988cd7', '2008-03-03 04:36:55', '2008-04-08 00:55:15', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('axdG9A6qKr3iwJadbiKLMM', 'cvcxv@sds.vj', 'ramu', 'grandi', 'male', 'us', 'kink kong', 'ghgf', 'United States', '2008-03-05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '586935906_6b9e8c26f7.jpg', NULL, 'b55237af2369a2a7b3b896db96807e9b271f5209', 'bef011a6cc22798bab9ec9ff17f559750378e90a', '2008-03-03 04:03:36', '2008-04-08 00:54:29', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('aOmqv66qOr3jhMadbiKLMM', 'Sdfd@dfdsf.vc', 'lokesh', 'srikanth', 'male', 'hyuijk', 'sdfdsf', 'dfdsf', 'United States', '2008-03-04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '429429873_b772b96890.jpg', NULL, '1d7275533c440d9bf12da8c4cab2aa3cf5ebfb44', '4f9496f00c5ec328218c90d6a1e654e29db03679', '2008-03-03 04:11:14', '2008-04-08 00:54:42', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('acw3JY6qSr3kRJadbiKLMM', 'dfg@ert.bnm', 'rajesh', 'krishna', 'male', 'ghgfh', 'fdg', 'hfgh', 'United States', '2008-03-19', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '41da85c8988abb95083cae5ecacd93d3a352c7ac', '491206961ad9b90cc55a7d3138d3d82521655162', '2008-03-03 04:17:20', '2008-03-03 04:18:20', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('a6bBbs5OOr3jCXadbiKLMM', 'admin1@admin.com', 'Julie', 'White', 'female', 'United Kingdom', 'sing fort', 'utansa', 'Hong Kong', '2008-01-08', 'India, U.s', 'india', 'playing cricket', 'nothing', 'programmer', 'no', 'Hard work', 'iStock_000004768533XSmall.jpg', '', '4e397fbe012e2874f145862e2c49fbbad8272eaf', 'b89432d1f7b118d66b08d6956f7c246df3582ee5', '2008-02-28 23:50:26', '2008-05-21 03:39:43', 1, '2008-05-21 03:39:43', NULL, NULL, 0, 1);
INSERT INTO `users` VALUES('cQ-CDgYzer3i8_adbiKLMM', 'testuser@sea.com', 'mahesh', 'varma', 'male', 'kakinada', 'kakinada', 'A.P', 'India', '1984-03-12', 'all', 'all', 'all', 'all', 'testing', 'testing', 'all', 'image0010403.jpg', 'Software, Hardware, EDP', '41eb13e4c7529f984f4ddc7b8023fa065ee553d9', 'adfba7bea6756ced535644c64507becf9bea951d', '2008-01-23 03:00:39', '2008-05-21 02:49:33', 0, '2008-05-20 21:45:58', NULL, NULL, 1, 2);
INSERT INTO `users` VALUES('ddy_h-ZYyr3j8uadbiKLMM', 'design@mbmaonline.com', 'Seasoned', 'Adventurer', 'male', 'Saint Germain', 'Paris', NULL, 'France', '1977-01-31', 'Paris, New York, Seattle, Boston, New Orleans, Hawaii, Mojave Desert', 'Croatia, Africa, Slovakia, Germany, Prague, Spain, London, Scotland, Canada, Mexico', 'Ensuring that Seasoned Adventurer Members benefit from using the site and enjoy the community.', 'Work is a pleasure.', 'To see that Seasoned Adventurer remains the best private social network community for people over 50.', NULL, NULL, 'sa.jpg', '', '10f5cb57d93263782c9339898cfce942c04f4ad1', '792b09834dbcd147138672607b31f88aaae6d3ca', '2008-01-30 05:30:30', '2008-04-08 00:54:46', 0, NULL, NULL, NULL, 0, 0);
INSERT INTO `users` VALUES('b5R09w5NSr3i7ladbiKLMM', 'hello@yahoo.co.in', 'gopi', '58788', 'female', 'kkd', 'fhghghfg', 'M.P', 'Select a Country', '2006-11-07', '', '', '', '', '', '', '', 'organicplants.jpg', '', '88c71154a76674960133e8fc30b8f02628ce1dd5', '1946fa76f1c9b07b766fe28545bccbfa65dd8f6a', '2008-02-28 22:04:51', '2008-04-08 00:55:56', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('d9P1nY_9qr3lb7adbiKLMM', 'umamahesh_nyros@gmail.com', 'ramesh', 'kumar', 'male', 'kakinada\r\n', 'Kakinada', '', 'Argentina', '1950-03-04', 'all the world', 'all the places around the world\r\n\r\n', 'playing cricket', 'nothing', 'all', 'no', 'all', NULL, NULL, 'c6a179bd6372426863833d3152227e330ad5f14b', '22a276afcd14829db6db41ed799fea72049cf35e', '2008-04-01 05:18:36', '2008-04-01 05:20:32', 0, NULL, NULL, NULL, 0, 0);
INSERT INTO `users` VALUES('b8gjxW5NOr3j38adbiKLMM', 'sharma_nyros@yahoo.com', 'Gopi', 'krishna', 'male', 'Rajahmundry.', 'Rjy', 'A.P', 'India', '2004-07-07', 'rjy', 'rjy', 'kkd', 'kkd', 'nothing', 'xyz', 'xyz', 'showletter9op.gif', '', 'dada2114eac35dfabd4c74149bd6a4f34499d676', 'f29ec265754b4ab84153b5d8eff95e3eb36ab7d3', '2008-02-28 21:57:45', '2008-04-08 00:58:11', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('a7C7CW5rKr3lB8adbiKLMM', 'ranilaxmi29@yahoo.com', 'Rani', 'Laxmi', 'female', 'us', 'us', 'us', 'United States', '1956-06-19', 'us,us,us', 'uk', 'tv', 'same', 'business', 'siva', 'life', 'Pongal-Greeting.jpg', NULL, '0e69dba165dc6fb19658565c837500ef18bba362', '13c23940fc68d22052c4fccb1e990ffbb53a80a7', '2008-02-27 03:49:04', '2008-04-08 00:58:22', 0, '2008-02-27 03:49:21', NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('b6ZlCa5pWr3lj_adbiKLMM', 'sivakrishna.motamarri@gmail.com', 'krishna', 'motamarri', 'male', 'Dno-31-90/2', 'narsipatnam', 'ap', 'India', '1957-05-27', 'Kakinada', 'Annavaram', 'tv', 'same', 'Software Engineer', 'siva', 'time', 'newyear46.jpg', NULL, 'a897d59793628bb9d310ad465985d17e2756f22c', '27961918e1807f0e7be99c43545dc8ee533eb5a5', '2008-02-27 00:23:15', '2008-04-08 00:58:32', 1, '2008-03-02 21:56:37', NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('b1sClA5pKr3lbMadbiKLMM', 'chaitubangari@gmail.com', 'srikanth', 'srikanth', 'male', 'india', 'Guntur', 'Andhra Pradesh ', 'India', '1960-02-24', 'India,paris,london', 'India,paris,london', 'cricket', 'none', 'none', 'none', 'none', '16189028.jpg', NULL, '41e4089e54e9dadd068b56a45bd4fc7565a89419', 'f49bc6dd6a625dc3545d3503eb860c6b411edfcc', '2008-02-27 00:01:38', '2008-04-08 01:01:02', 0, '2008-02-27 20:59:37', NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('d25r565pKr3kSqadbiKLMM', 'sivakrishna_nyros@yahoo.com', 'siva', 'krishna', 'male', 'Dno:- 3-59/9', 'Kakinada', 'ap', 'India', '1960-09-09', 'Narsipatnam, Hyderabad', 'Annavaram', 'Playing Cricket', 'same', 'Software Engineer', 'uma', 'money', 'main.jpg', NULL, '0508409e213f30d5a4582e9ae35b4233e5f98321', '8eb0440882a6daf0c2841865c5ce9ef675052f23', '2008-02-27 00:05:15', '2008-04-08 00:58:45', 0, '2008-02-27 02:56:30', NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('dsGgZ85iOr3lZpadbiKLMM', 'dennis@mbmaonline.com', 'Dennis', 'Payne', 'male', '2023 E Sims Way #203', 'Port Townsend', 'WA', 'United States', '1984-03-12', 'Seattle', 'Seattle, WA', 'all', 'all', 'all', '', 'all', 'DP_photo_P000833a.jpg', 'Sales', 'd53501ebb648b42b35c3c8798eb21fbe4ed53cb2', 'f999a77fd638940af6e93597638de5998e5b694b', '2008-02-26 10:49:40', '2008-04-08 00:26:17', 1, '2008-04-03 10:55:49', NULL, NULL, 0, 0);
INSERT INTO `users` VALUES('aNL1N-5pGr3kzTadbiKLMM', 'chaitanyab_nyros@gmail.com', 'chaitu', 'chaitu', 'male', 'vijayawada,andhrapradesh', 'vijayawada', 'Andhra Pradesh', 'India', '1960-02-11', 'Paris, New York, Seattle, Boston, New Orleans, Haw...', 'Croatia, Africa, Slovakia, Germany, Prague, Spain, London, Scotland, Canada, Mexico\r\n\r\n', 'Ensuring that Seasoned Adventurer Members benefit from using the site and enjoy the community.', 'Good', 'To see that Seasoned Adventurer remains the best private social network community for people over 50.', 'uma', 'To see Nature', 'images.jpg', NULL, '1ba1a36e3cdb7146bb6619a3502496ade7d91ebf', '0098f9cfb28d38e10203805390cb7f3fb9d417db', '2008-02-26 23:52:18', '2008-04-08 00:58:56', 1, '2008-02-27 22:52:59', NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('drpbRQ6qCr3l09adbiKLMM', 'asd@dsf.com', 'mutu', 'krishna', 'male', 'dsfgsdfg\r\n', 'asdsa', 'fdsg', 'Antarctica', '2008-03-05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0df74f931abdd4ba864be369993ad591ee5270ed', 'b745633c8736cb72d60a7be95d999c816164f3e2', '2008-03-03 03:54:29', '2008-03-03 03:54:50', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('aGQCYO6ner3jm_adbiKLMM', 'sdfds@sdsa.co', 'vasanth', 'rao', 'female', 'afaf\r\n', 'sdfdsf', NULL, 'Aland Islands', '2008-03-04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '92b6d5fc7e5b8c2dd6641cbb1b44e07489d838e8', '366cae7b1ca142a1729254982dbd5dcf9a9b483b', '2008-03-02 21:23:00', '2008-03-02 21:23:57', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('c4meXc6nar3l_qadbiKLMM', 'sadasd@sdd.vo', 'raja', 'srinu', 'male', 'dsfdsf\r\n', 'adas', NULL, 'United States', '2008-03-04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'dacc63e482eb8560a98b15488964912aaeb15e24', '8aa6b75648fc191622ad6ef23de5ab1d2f6b0970', '2008-03-02 21:20:05', '2008-03-02 21:24:13', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('a8IkKG6m0r3lrkadbiKLMM', 'siva2@sea.com', 'siva2', 'krishna', 'male', 'nrpm street', 'nrpm', 'ap', 'India', '2075-09-09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'image001.jpg', NULL, 'b21a30e0ae7aebb1cc4864415a4edcc787fa87f8', 'be15483824c9e2e6bdb787fd2c84c7a6406932cd', '2008-03-02 20:55:09', '2008-04-08 01:01:14', 0, NULL, NULL, NULL, 0, 0);
INSERT INTO `users` VALUES('csUjJC5WSr3j5ZadbiKLMM', 'symonds@sea.com', 'admin', 'symonds', 'male', 'kkd', 'ruby', NULL, 'Select a Country', '2008-03-19', 'kakinada', NULL, '', '', '', '', '', NULL, 'Sales', 'e1e2bf3a3270577ff79e9e965d81578e81165a32', '12efaa7281aa77fcd146386c91effba707aa8c42', '2008-02-29 15:16:20', '2008-03-03 22:08:10', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('cJnEQ06mOr3kZOadbiKLMM', 'dennis@coffeeroom.com', 'Dennis', 'Payne', 'male', '2023 E Sims Way #203', 'Port Townsend', 'WA', 'United States', '2008-02-12', '', '', '', '', '', NULL, 'Getting this site finished by Monday', NULL, NULL, 'ee3d30e53f03d613370ea556f0c03553e373a90b', 'e65562d269b42af37c87f32f035bc13d26728185', '2008-03-02 20:36:33', '2008-03-03 02:13:45', 0, '2008-03-03 02:07:31', NULL, NULL, 0, 0);
INSERT INTO `users` VALUES('czvIW46ryr3lDIadbiKLMM', 'lokesh@gmail.com', 'mahesh', 'varma', 'male', 'hyderabada', 'mysore', 'andhra', 'India', '1960-03-03', 'hard work', 'hard work', 'hard work', 'hard work', 'hard work', 'no reference', 'hard work', '242261197_cd15d85e41_m.jpg', NULL, '28b634916eceff5304f07adeeb92caf46f9e4792', 'bc833f7dcec27c0fab7a52ff80a10074cf674a05', '2008-03-03 05:40:18', '2008-04-08 01:01:22', 0, NULL, NULL, NULL, 1, 0);
INSERT INTO `users` VALUES('aluJPk6Aer3lB5adbiKLMM', 'sales@seasonedadventurer.com', 'Pumpkin', 'Patch', 'male', '102 Main Street\r\nPatch, AR', 'Seattle', 'WA', 'United States', '1955-02-27', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'bd41b507db168b8aa5bc7de30c9257d067e07462', 'deeaf6f09744e75ce934a5ff53ab1e4e079045e4', '2008-03-03 22:11:20', '2008-03-03 23:48:28', 0, '2008-03-03 23:20:08', NULL, NULL, 0, 0);
INSERT INTO `users` VALUES('aiFGbm_Wqr3kCnadbiKLMM', 'murali_nyros@yahoo.com', 'murali', 'krishna', 'male', 'gudur', 'nellore', 'A.P', 'India', '1984-03-12', 'gudur,khammam,kota,tirupathi', 'araku,vizag', 'playing cricket,guitarist', 'Alone', 'S.E', 'mahesh', 'Relations', 'image001m.jpg', NULL, '64e757b86f403cd1a6b15366034ecf1a31f15bb1', 'ad31b3fa2a9497de36a9df59e9267ad62470a103', '2008-03-31 04:22:50', '2008-05-20 21:46:09', 0, '2008-04-07 22:03:09', NULL, NULL, 0, 2);
INSERT INTO `users` VALUES('bMEACe6AWr3kmXadbiKLMM', 'martha@kmart.com', 'Martha', 'Stewart', 'female', '333 Croak Rd', 'Marthas Vineyard', 'MA', 'United States', '0004-12-12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '597e63e046e9ea77a0bdbb6fad142f89.jpg', NULL, 'a142eb4fd821a72e142d86427757956addd0d196', '6f457182f7d755a4d7d03f347bf568d21d3968df', '2008-03-03 23:32:37', '2008-04-08 01:01:37', 1, '2008-03-07 06:15:36', NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_mails`
--

CREATE TABLE `user_mails` (
  `id` int(11) NOT NULL auto_increment,
  `from_user` varchar(32) NOT NULL,
  `to_user` varchar(32) NOT NULL,
  `date_sent` datetime NOT NULL,
  `subject` varchar(225) default NULL,
  `message` text,
  `user_read` tinyint(4) NOT NULL default '0',
  `from_deleted` tinyint(4) NOT NULL default '0',
  `to_deleted` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `user_mails`
--

INSERT INTO `user_mails` VALUES(52, 'dsGgZ85iOr3lZpadbiKLMM', 'dsGgZ85iOr3lZpadbiKLMM', '2008-04-03 10:57:59', 'test SA', 'test SA', 0, 0, 0);
INSERT INTO `user_mails` VALUES(51, 'aiFGbm_Wqr3kCnadbiKLMM', 'a6bBbs5OOr3jCXadbiKLMM', '2008-04-01 06:16:38', 'hai', 'hai admin', 0, 0, 1);
INSERT INTO `user_mails` VALUES(50, 'a6bBbs5OOr3jCXadbiKLMM', 'a6bBbs5OOr3jCXadbiKLMM', '2008-04-01 05:57:09', 'hai', 'hai admin\r<br />', 0, 1, 0);
INSERT INTO `user_mails` VALUES(49, 'a6bBbs5OOr3jCXadbiKLMM', 'a6bBbs5OOr3jCXadbiKLMM', '2008-04-01 05:55:32', 'hai admin', 'hai admin how r u', 0, 0, 0);
INSERT INTO `user_mails` VALUES(48, 'a6bBbs5OOr3jCXadbiKLMM', 'a6bBbs5OOr3jCXadbiKLMM', '2008-04-01 05:28:02', 'hai admin', 'hai admin how r u', 1, 0, 0);
INSERT INTO `user_mails` VALUES(47, 'a6bBbs5OOr3jCXadbiKLMM', 'aiFGbm_Wqr3kCnadbiKLMM', '2008-04-01 05:08:41', 'hai', 'hai murali ', 0, 0, 0);
INSERT INTO `user_mails` VALUES(46, 'a6bBbs5OOr3jCXadbiKLMM', 'aiFGbm_Wqr3kCnadbiKLMM', '2008-04-01 05:07:31', 'hai', 'hai how r u', 0, 0, 0);
INSERT INTO `user_mails` VALUES(45, 'aiFGbm_Wqr3kCnadbiKLMM', 'cQ-CDgYzer3i8_adbiKLMM', '2008-04-01 04:39:08', 'Testing from new user murali', 'hi.............', 0, 0, 1);
INSERT INTO `user_mails` VALUES(44, 'aiFGbm_Wqr3kCnadbiKLMM', 'cQ-CDgYzer3i8_adbiKLMM', '2008-04-01 03:38:09', 'hai', 'hai how r u', 0, 0, 1);
INSERT INTO `user_mails` VALUES(43, 'aiFGbm_Wqr3kCnadbiKLMM', 'cQ-CDgYzer3i8_adbiKLMM', '2008-03-31 04:36:05', 'Acknowledgment from new friend', 'Hi....', 0, 0, 1);
INSERT INTO `user_mails` VALUES(42, 'cQ-CDgYzer3i8_adbiKLMM', 'aiFGbm_Wqr3kCnadbiKLMM', '2008-03-31 04:34:09', 'hai ', 'hai how r u', 0, 1, 0);
INSERT INTO `user_mails` VALUES(39, 'cQ-CDgYzer3i8_adbiKLMM', 'cQ-CDgYzer3i8_adbiKLMM', '2008-03-16 23:44:32', 'hai', 'hai', 0, 1, 1);
INSERT INTO `user_mails` VALUES(40, 'cQ-CDgYzer3i8_adbiKLMM', 'cQ-CDgYzer3i8_adbiKLMM', '2008-03-23 10:07:19', 'hai', 'hai howr u', 0, 1, 1);
INSERT INTO `user_mails` VALUES(37, 'aNL1N-5pGr3kzTadbiKLMM', 'b6ZlCa5pWr3lj_adbiKLMM', '2008-02-27 01:22:25', 'again hi', 'again hi', 0, 0, 0);
INSERT INTO `user_mails` VALUES(36, 'aNL1N-5pGr3kzTadbiKLMM', 'b6ZlCa5pWr3lj_adbiKLMM', '2008-02-27 01:18:33', 'hi', 'hi kirishna how is krishna movie', 0, 0, 0);
INSERT INTO `user_mails` VALUES(41, 'aiFGbm_Wqr3kCnadbiKLMM', 'cQ-CDgYzer3i8_adbiKLMM', '2008-03-31 04:31:35', 'Testing from new user', 'test', 0, 0, 1);
INSERT INTO `user_mails` VALUES(34, 'b1sClA5pKr3lbMadbiKLMM', 'aNL1N-5pGr3kzTadbiKLMM', '2008-02-27 00:11:05', 'hello', 'hello!!!!!!', 0, 0, 0);
INSERT INTO `user_mails` VALUES(38, 'd25r565pKr3kSqadbiKLMM', 'b6ZlCa5pWr3lj_adbiKLMM', '2008-02-27 03:59:35', 'hello', 'hi krishna this is siva , i wrote a letter to u see it fast............\r<br />\r<br />......................\r<br /> thank u .....................\r<br />.....................................................siva.....', 0, 0, 0);
INSERT INTO `user_mails` VALUES(53, 'dsGgZ85iOr3lZpadbiKLMM', 'dsGgZ85iOr3lZpadbiKLMM', '2008-04-03 10:59:41', 'Test okay', 'test okay', 0, 0, 0);
INSERT INTO `user_mails` VALUES(58, 'a6bBbs5OOr3jCXadbiKLMM', 'cQ-CDgYzer3i8_adbiKLMM', '2008-05-20 04:05:18', 'hi', 'hi its an test mail', 0, 0, 0);
INSERT INTO `user_mails` VALUES(54, 'cQ-CDgYzer3i8_adbiKLMM', 'a6bBbs5OOr3jCXadbiKLMM', '2008-04-03 23:38:22', 'hai', 'hai', 0, 1, 1);
INSERT INTO `user_mails` VALUES(55, 'cQ-CDgYzer3i8_adbiKLMM', 'aiFGbm_Wqr3kCnadbiKLMM', '2008-04-04 01:26:23', 'hai', 'hai', 0, 1, 0);
INSERT INTO `user_mails` VALUES(56, 'cQ-CDgYzer3i8_adbiKLMM', 'aiFGbm_Wqr3kCnadbiKLMM', '2008-04-04 02:20:02', 'hai', 'hai mahesh', 0, 0, 0);
INSERT INTO `user_mails` VALUES(57, 'a6bBbs5OOr3jCXadbiKLMM', 'a6bBbs5OOr3jCXadbiKLMM', '2008-05-19 15:24:59', 'Test email message sent on May 19', 'Test email message sent on May 19', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_networks`
--

CREATE TABLE `user_networks` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` varchar(32) NOT NULL default '0',
  `friend_id` varchar(32) NOT NULL default '0',
  `created_at` datetime default NULL,
  `comment` varchar(255) default '',
  `status` int(11) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `user_networks`
--

INSERT INTO `user_networks` VALUES(8, 'b1sClA5pKr3lbMadbiKLMM', 'd25r565pKr3kSqadbiKLMM', '2008-02-27 00:16:40', '', 0);
INSERT INTO `user_networks` VALUES(13, 'b1sClA5pKr3lbMadbiKLMM', 'b6ZlCa5pWr3lj_adbiKLMM', '2008-02-27 00:48:27', '', 0);
INSERT INTO `user_networks` VALUES(14, 'cQ-CDgYzer3i8_adbiKLMM', 'aNL1N-5pGr3kzTadbiKLMM', '2008-02-27 00:59:43', '', 0);
INSERT INTO `user_networks` VALUES(15, 'b6ZlCa5pWr3lj_adbiKLMM', 'aNL1N-5pGr3kzTadbiKLMM', '2008-02-27 01:04:47', '', 0);
INSERT INTO `user_networks` VALUES(16, 'd25r565pKr3kSqadbiKLMM', 'aNL1N-5pGr3kzTadbiKLMM', '2008-02-27 01:05:06', '', 0);
INSERT INTO `user_networks` VALUES(17, 'd25r565pKr3kSqadbiKLMM', 'b6ZlCa5pWr3lj_adbiKLMM', '2008-02-27 01:19:49', '', 0);
INSERT INTO `user_networks` VALUES(18, 'd25r565pKr3kSqadbiKLMM', 'a7C7CW5rKr3lB8adbiKLMM', '2008-02-27 03:53:00', '', 0);
INSERT INTO `user_networks` VALUES(19, 'aNL1N-5pGr3kzTadbiKLMM', 'dsGgZ85iOr3lZpadbiKLMM', '2008-02-27 21:07:45', '', 0);
INSERT INTO `user_networks` VALUES(20, 'cJnEQ06mOr3kZOadbiKLMM', 'dsGgZ85iOr3lZpadbiKLMM', '2008-03-02 21:12:48', '', 0);
INSERT INTO `user_networks` VALUES(21, 'cQ-CDgYzer3i8_adbiKLMM', 'aluJPk6Aer3lB5adbiKLMM', '2008-03-03 23:41:26', '', 0);
INSERT INTO `user_networks` VALUES(22, 'cQ-CDgYzer3i8_adbiKLMM', 'ddy_h-ZYyr3j8uadbiKLMM', '2008-03-16 23:41:04', '', 0);
INSERT INTO `user_networks` VALUES(23, 'cQ-CDgYzer3i8_adbiKLMM', 'bMEACe6AWr3kmXadbiKLMM', '2008-03-16 23:47:15', '', 0);
INSERT INTO `user_networks` VALUES(24, 'cQ-CDgYzer3i8_adbiKLMM', 'b6ZlCa5pWr3lj_adbiKLMM', '2008-03-18 04:36:26', '', 0);
INSERT INTO `user_networks` VALUES(25, 'aiFGbm_Wqr3kCnadbiKLMM', 'cQ-CDgYzer3i8_adbiKLMM', '2008-03-31 04:32:36', '', 1);
INSERT INTO `user_networks` VALUES(26, 'a6bBbs5OOr3jCXadbiKLMM', 'aiFGbm_Wqr3kCnadbiKLMM', '2008-04-01 05:04:51', '', 0);
INSERT INTO `user_networks` VALUES(27, 'a6bBbs5OOr3jCXadbiKLMM', 'cQ-CDgYzer3i8_adbiKLMM', '2008-04-01 09:24:48', '', 1);
INSERT INTO `user_networks` VALUES(28, 'a6bBbs5OOr3jCXadbiKLMM', 'b1sClA5pKr3lbMadbiKLMM', '2008-05-19 15:46:54', '', 0);
INSERT INTO `user_networks` VALUES(29, 'a6bBbs5OOr3jCXadbiKLMM', 'dsGgZ85iOr3lZpadbiKLMM', '2008-05-19 15:48:32', '', 0);
INSERT INTO `user_networks` VALUES(30, 'cQ-CDgYzer3i8_adbiKLMM', 'czvIW46ryr3lDIadbiKLMM', '2008-05-20 22:46:20', '', 0);
INSERT INTO `user_networks` VALUES(31, 'cQ-CDgYzer3i8_adbiKLMM', 'c-GWRk6q0r3jZcadbiKLMM', '2008-05-20 22:50:06', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_settings`
--

CREATE TABLE `user_settings` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` varchar(32) NOT NULL,
  `system_updates` tinyint(4) NOT NULL default '1',
  `partner_offers` tinyint(4) NOT NULL default '1',
  `network_requests` tinyint(4) NOT NULL default '1',
  `new_mail` tinyint(4) NOT NULL default '1',
  `display_year` tinyint(4) NOT NULL default '0',
  `show_online` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `user_settings`
--

INSERT INTO `user_settings` VALUES(9, 'cQ-CDgYzer3i8_adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(51, 'bpzReU5R4r3lnladbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(50, 'dCwX0a5RGr3jv7adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(65, 'aiFGbm_Wqr3kCnadbiKLMM', 1, 0, 1, 0, 1, 1);
INSERT INTO `user_settings` VALUES(49, 'dgX7rM5Rqr3jqyadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(48, 'c7XzE-5Rmr3iXKadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(47, 'aLc2Og5Rmr3lw2adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(46, 'al2I7e5Rir3lE6adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(16, 'ddy_h-ZYyr3j8uadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(45, 'dmMB005Rar3kq-adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(44, 'bJEEME5Q0r3kRDadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(43, 'a1ueJ25Pqr3jOEadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(41, 'a6bBbs5OOr3jCXadbiKLMM', 1, 1, 1, 1, 1, 1);
INSERT INTO `user_settings` VALUES(40, 'b5R09w5NSr3i7ladbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(38, 'a7C7CW5rKr3lB8adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(39, 'b8gjxW5NOr3j38adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(37, 'b6ZlCa5pWr3lj_adbiKLMM', 1, 1, 1, 0, 1, 1);
INSERT INTO `user_settings` VALUES(36, 'd25r565pKr3kSqadbiKLMM', 1, 1, 1, 1, 1, 1);
INSERT INTO `user_settings` VALUES(35, 'b1sClA5pKr3lbMadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(32, 'dsGgZ85iOr3lZpadbiKLMM', 1, 1, 1, 1, 1, 1);
INSERT INTO `user_settings` VALUES(34, 'aNL1N-5pGr3kzTadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(52, 'csUjJC5WSr3j5ZadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(53, 'cJnEQ06mOr3kZOadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(54, 'a8IkKG6m0r3lrkadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(55, 'c4meXc6nar3l_qadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(56, 'aGQCYO6ner3jm_adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(57, 'drpbRQ6qCr3l09adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(58, 'axdG9A6qKr3iwJadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(59, 'aOmqv66qOr3jhMadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(60, 'acw3JY6qSr3kRJadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(61, 'c-GWRk6q0r3jZcadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(62, 'czvIW46ryr3lDIadbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(63, 'aluJPk6Aer3lB5adbiKLMM', 1, 1, 1, 1, 0, 1);
INSERT INTO `user_settings` VALUES(64, 'bMEACe6AWr3kmXadbiKLMM', 1, 1, 1, 1, 1, 1);
INSERT INTO `user_settings` VALUES(66, 'd9P1nY_9qr3lb7adbiKLMM', 1, 1, 1, 1, 0, 1);
